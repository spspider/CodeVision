//The publication "Connection of joypads from a game consoles to the USB".
//The Russian magazine �RADIO�, 2007, number 1, pages 28-31, http://www.radio.ru
//Author � Ryumik Sergey.
//=============================================================================
//Joypads_PSX, "common.h"
//=============================================================================
#define F_CPU   12000000UL //Frequency ZQ1
#include <avr/io.h> //Input-output
#include <avr/interrupt.h> //Interrupts
#include <avr/pgmspace.h> //Space
//=============================================================================
#include "usbdrv.h" //Driver_USB
//=============================================================================
//Output_structure
typedef struct
{
  uchar x; //Byte-0, � (0...255)
  uchar y; //Byte-1, Y (0...255)
		uchar z; //Byte-2, Handle-1 (0...255)
  uchar p; //Byte-3, Handle-2 (0...255)

  union {
    uchar buttons; //Byte-4, buttons 8
    struct
    {
      uchar btn1:    1; //0, 1
      uchar btn2:    1; //0, 1
      uchar btn3:    1; //0, 1
      uchar btn4:    1; //0, 1
      uchar btn5:    1; //0, 1
      uchar btn6:    1; //0, 1
      uchar btn7:    1; //0, 1
      uchar btn8:    1; //0, 1
    } b;
  } u;
		union {
    uchar but; //Byte-5, buttons 4
    struct
    {
      uchar btn9:    1; //0, 1
      uchar btn10:   1; //0, 1
      uchar btn11:   1; //0, 1
      uchar btn12:   1; //0, 1
      uchar padding: 4; //Not use
				} b;
  } w;
} t_PsxController;
//=============================================================================
extern t_PsxController psx_data[2];
//=============================================================================
//Functions
extern void inDecoderInit(void); //Initialization
extern void inDecoderPoll(void); //Input
extern void outSendData(void); //Output
//=============================================================================
//Configuration of ports ATmega8
#define HL1 PD4 //LED HL1

#define DAT1 PB1 //DAT (joypad-1)
#define CMD1 PB2 //CMD (joypad-1)
#define SEL1 PC0 //SEL (joypad-1)
#define CLK1 PC1 //CLK (joypad-1)
#define ACK1 PD3 //ACK (joypad-1)

#define DAT2 PC2 //DAT (joypad-2)
#define CMD2 PC3 //CMD (joypad-2)
#define SEL2 PC4 //SEL (joypad-2)
#define CLK2 PC5 //CLK (joypad-2)
#define ACK2 PD1 //ACK (joypad-2)
