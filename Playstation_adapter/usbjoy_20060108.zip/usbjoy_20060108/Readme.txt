------------------------------------------------------------------------------
The publication <Connection of joypads from a game consoles to the USB>.
The Russian magazine <RADIO>, 2007, number 1, pages 28-31, http://www.radio.ru
Author � Sergey Ryumik.
------------------------------------------------------------------------------
1) <Programm_Dendy> - folders with source for joypad by Dendy (NES).
2) <Programm_PSX> - folders with source for joypad by PSX, PS2.
3) <Programm_Sega> - folders with source for joypad by SEGA Mega Drive-II.
4) <Schematics> - folder with schematics in English.
------------------------------------------------------------------------------
All of the source are compiled by the WinAVR-20060421.
------------------------------------------------------------------------------
On a site ftp://ftp.radio.ru/pub/2007/01/usbjoy/
are placed additional HEX, SCH and PCB for 1-4 players (text in Russian).
Figures in the name of a HEX-files designates number of the players (joypads).
For example,
=dendy3.hex= - HEX-codes of the Dendy for three joypads,
=psx2.hex= - HEX-codes of the PlayStation for two joypads,
=sega1-2.hex= - HEX-codes of the SEGA Mega Drive-II for one joypad, which
can be switched to the first or second player by his button MODE.
------------------------------------------------------------------------------
Start version: 20060108

