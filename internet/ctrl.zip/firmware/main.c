#include <avr/io.h>
#include <avr/pgmspace.h>
#include "lan.h"

void udp_packet(eth_frame_t *frame, uint16_t len)
{
	ip_packet_t *ip = (void*)(frame->data);
	udp_packet_t *udp = (void*)(ip->data);

	if(udp->to_port == htons(1990)) 
	{
		if(!memcmp_P(udp->data, PSTR("preved"), 6)) 
		{
			memcpy_P(udp->data, PSTR("medved"), 6);
			udp_reply(frame, 6);
		} 
		else if(!memcmp_P(udp->data, PSTR("value_"), 6)) 
		{
			PORTA = udp->data[6];
		}
	}
}

int main()
{
	DDRA = 0xff;
	
	counter_init();
	lan_init();
	sei();
	
	while(1)
		lan_poll();
	
	return 0;
}

