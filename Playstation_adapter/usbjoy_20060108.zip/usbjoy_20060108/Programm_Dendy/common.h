//The publication "Connection of joypads from a game consoles to the USB".
//The Russian magazine �RADIO�, 2007, number 1, pages 28-31, http://www.radio.ru
//Author � Ryumik Sergey.
//=============================================================================
//Joypads_Dendy (NES), "common.h"
//=============================================================================
#define F_CPU   12000000UL //Frequency ZQ1
#include <avr/io.h> //Input-output
#include <avr/interrupt.h> //Interrupts
#include <avr/pgmspace.h> //Space
//=============================================================================
#include "usbdrv.h" //Driver_USB
//=============================================================================
//Output_structure
typedef struct
{
  uchar x; //Byte-0, � (0, 1, 2)
  uchar y; //Byte-1, Y (0, 1, 2)
  union {
    uchar buttons; //Byte-2, buttons 4
    struct
    {
      uchar btn1: 1; //0, 1
      uchar btn2: 1; //0, 1
      uchar btn3: 1; //0, 1
      uchar btn4: 1; //0, 1
      uchar padding: 4; //Not use
    } b;
  } u;
} t_DendyController;
//=============================================================================
extern t_DendyController dendy_data[4];
//=============================================================================
//Functions
extern void inDecoderInit(void); //Initialization
extern void inDecoderPoll(void); //Input
extern void outSendData(void); //Output
//=============================================================================
//Configuration of ports ATmega8
#define HL1 PD4 //LED HL1
#define SYN PC0 //SYN (joypad-1...4)
#define PEX PC5 //PE joypad-1...4)
#define OU1 PC1 //OUT (joypad-1)
#define OU2 PC2 //OUT (joypad-2)
#define OU3 PC3 //OUT (joypad-3)
#define OU4 PC4 //OUT (joypad-4)
