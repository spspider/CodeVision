<?php 
	header("Pragma: no-cache");
	header("Cache-control: no-cache");
	echo((260 + mt_rand() % 20) / 10);