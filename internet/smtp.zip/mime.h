#pragma once

#include <inttypes.h>

uint8_t base64_encode(char *buf, uint8_t *data, uint8_t len);
