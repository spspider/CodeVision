//The publication "Connection of joypads from a game consoles to the USB".
//The Russian magazine �RADIO�, 2007, number 1, pages 28-31, http://www.radio.ru
//Author � Ryumik Sergey.
//=============================================================================
//Joypads_Dendy (NES), "main_dendy.c", number of joypads = 4
//=============================================================================
//The author of publication expresses large thanks of Oleg Semyonov (town Sevastopol)
//for the valuable remarks on structural organization of the interface USB
//=============================================================================
//ATmega8, WinAVR-20060421, "main_dendy.hex"
//Fuses: CKOPT="0", BODEN="0"
//=============================================================================
#include "common.h"
//-----------------------------------------------------------------------------
int main(void) //Start_main
{
 	usbInit(); //Initialization of USB_driver
		inDecoderInit(); //Initialization of decoder_buttons
	 sei(); //Enable interrupt
  while (1) //Infinite cycle
  {
    inDecoderPoll(); //Input of buttons_joypads
    outSendData(); //Output data
    usbPoll(); //Send data
  }
}
