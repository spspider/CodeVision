//The publication "Connection of joypads from a game consoles to the USB".
//The Russian magazine �RADIO�, 2007, number 1, pages 28-31, http://www.radio.ru
//Author � Ryumik Sergey.
//=============================================================================
//Joypads_PSX, "in_psx.c", number of joypads = 2
//=============================================================================
#include "common.h"
//=============================================================================
t_PsxController psx_data[2];
//=============================================================================
//Initialization
void inDecoderInit(void)
{
  PORTB=0xFF; DDRB=0x14; //PB2,PB4 - outputs, other - inputs with R
  PORTC=0xFF; DDRC=0x3B; //PC0,PC1,PC3-PC5 - outputs, other - inputs with R
  PORTD |= 0xFA; DDRD |= 0x10; //PD4=output, other=inputs
		TCCR2 = 0x0F; //Timer-2, CTC, :1024
		OCR2 = 0x6A; //Time 9 ms, F=12 MHz
		TIFR |= _BV(OCF2); //Start_flag
}
//-----------------------------------------------------------------------------
//Check of buttons
void inDecoderPoll(void)
{ 
  uchar sl1,jl1,jr1,st1,l21,r21,l11,r11,aa1,oo1,xx1,dd1,up1,dn1,lf1,rg1; //Joypad-1 (buttons)
  uchar sl2,jl2,jr2,st2,l22,r22,l12,r12,aa2,oo2,xx2,dd2,up2,dn2,lf2,rg2; //Joypad-2 (buttons)
		uchar fxx1,fyy1,rxx1=0,ryy1=0,bbb1,ccc1; //Outputs (joypad-1)
		uchar fxx2,fyy2,rxx2=0,ryy2=0,bbb2,ccc2; //Outputs (joypad-2)
  uchar out1[16]; //Outputs 8 bits (joypad-1)
  uchar out2[16]; //Outputs 8 bits (joypad-2)
  uchar k; //Counter
		uchar analog1; //=1 Analog mode (joypad-1)
		uchar analog2; //=1 Analog mode (joypad-2)
		unsigned int pause; //Counter of time
  static uchar h=0; //For LED HL1

  if (bit_is_set(TIFR,OCF2)) //If not 9 ms
		{
		  TIFR |= _BV(OCF2); //Start
		  if (++h > 30) //Time 30*9=270 ms
    {
      h=0; //Clear of a count
						PORTD ^= _BV(HL1); //Blink LED HL1 (270 ms)
				}
				for (k=0; k<16; k++) out1[k]=out2[k]=0; //Clear
				analog1=analog2=0; //Digital mode (joypad-1, joypad-2)
				PORTB |= _BV(CMD1); //CMD=1
				PORTC |= _BV(CMD2); //CMD=1
				PORTC |= _BV(CLK1); //CLK=1
				PORTC |= _BV(CLK2); //CLK=1
				PORTC &= ~_BV(SEL1); //SEL=0
				PORTC &= ~_BV(SEL2); //SEL=0
    //----------------------------------------------------------------------
				for (k=0; k<8; k++) //Byte-1
    { PORTC &= ~_BV(CLK1); //CLK=0
				  PORTC &= ~_BV(CLK2); //CLK=0
      if (k==1)
      { PORTB &= ~_BV(CMD1); //CMD=0
						  PORTC &= ~_BV(CMD2); //CMD=0
						}
      for (pause=1400; pause > 0; pause--); //Time CLK (0)
      PORTC |= _BV(CLK1); //CLK=1
						PORTC |= _BV(CLK2); //CLK=1
      for (pause=1400; pause > 0; pause--); //Time CLK (1)
    }
    PORTB |= _BV(CMD1); //CMD=1
				PORTC |= _BV(CMD2); //CMD=1
    for (pause=3000; pause > 0; pause--); //Long pause
    //----------------------------------------------------------------------
				for (k=0; k<8; k++) //Byte-2
    { PORTC &= ~_BV(CLK1); //CLK=0
				  PORTC &= ~_BV(CLK2); //CLK=0
				  for (pause=1400; pause > 0; pause--); //Time CLK (0)
      if (k==1)
      { PORTB |= _BV(CMD1); //CMD=1
						  PORTC |= _BV(CMD2); //CMD=1
						  if(bit_is_set(PINB,DAT1)) analog1++; //Analog mode (joypad-1)
								if(bit_is_set(PINC,DAT2)) analog2++; //Analog mode (joypad-2)
						}
      else
      { if (k==6)
        { PORTB |= _BV(CMD1); //CMD=1
          PORTC |= _BV(CMD2); //CMD=1
        }
        else
        { PORTB &= ~_BV(CMD1); //CMD=0
								  PORTC &= ~_BV(CMD2); //CMD=0
								}
      }
		    if(k==3)
						{ if(bit_is_set(PINB,DAT1)) analog1=0xFF; //Analog mode (joypad-1)
						  if(bit_is_set(PINC,DAT2)) analog2=0xFF; //Analog mode (joypad-2)
						}
      PORTC |= _BV(CLK1); //CLK=1
						PORTC |= _BV(CLK2); //CLK=1
      for (pause=1400; pause > 0; pause--); //Time CLK (1)
    }
    PORTB |= _BV(CMD1); //CMD=1
				PORTC |= _BV(CMD2); //CMD=1
    for (pause=3000; pause > 0; pause--); //Long pause
    //PORTB &= ~_BV(CMD1); //CMD=0
				//PORTC &= ~_BV(CMD2); //CMD=0
    //-----------------------------------------------------------------------  
				for (k=0; k<8; k++) //Byte-3
    { PORTC &= ~_BV(CLK1); //CLK=0
				  PORTC &= ~_BV(CLK2); //CLK=0
				  for (pause=1400; pause > 0; pause--); //Time CLK (0)
      PORTC |= _BV(CLK1); //CLK=1
						PORTC |= _BV(CLK2); //CLK=1
      for (pause=1400; pause > 0; pause--); //Time CLK (1)
    }
    for (pause=3000; pause > 0; pause--); //Long pause
				//------------------------------------------------------------------------		
    for (k=0; k<16; k++) //Byte-4, byte-5
    { PORTC &= ~_BV(CLK1); //CLK=0
				  PORTC &= ~_BV(CLK2); //CLK=0
      for (pause=1400; pause > 0; pause--); //Time CLK (0)
      if (k==15) //Read data
      { if(bit_is_clear(PINB,DAT1)) out1[k]++;
						  if(bit_is_clear(PINC,DAT2)) out2[k]++;
        PORTC |= _BV(CLK1); //CLK=1
								PORTC |= _BV(CLK2); //CLK=1
      }
      else
      { PORTC |= _BV(CLK1); //CLK=1
						  PORTC |= _BV(CLK2); //CLK=1
	       for (pause=100; pause > 0; pause--); //Pause
        if(bit_is_clear(PINB,DAT1)) out1[k]++;
								if(bit_is_clear(PINC,DAT2)) out2[k]++;
      }
      if (k==7) for (pause=3000; pause > 0; pause--); //Long pause
						for (pause=1400; pause > 0; pause--); //Time CLK (1)
    }
    for (pause=2000; pause > 0; pause--); //Pause
//Inputs (joypad-1)
				sl1=out1[0];
    jl1=out1[1];
    jr1=out1[2];
    st1=out1[3];
    up1=out1[4];
    rg1=out1[5];
    dn1=out1[6];
    lf1=out1[7];
				l21=out1[8];
    r21=out1[9];
    l11=out1[10];
    r11=out1[11];
    aa1=out1[12];
    oo1=out1[13];
    xx1=out1[14];
    dd1=out1[15];
	
	//Inputs (joypad-2)
				sl2=out2[0];
    jl2=out2[1];
    jr2=out2[2];
    st2=out2[3];
    up2=out2[4];
    rg2=out2[5];
    dn2=out2[6];
    lf2=out2[7];
				l22=out2[8];
    r22=out2[9];
    l12=out2[10];
    r12=out2[11];
    aa2=out2[12];
    oo2=out2[13];
    xx2=out2[14];
    dd2=out2[15];
//Joypad-1 (LEFT-RIGHT)
    if ((lf1 == 0)&&(rg1 != 0)) fxx1=255;
		  else
		  {
				  if ((lf1 != 0)&&(rg1 == 0)) fxx1=0;
			   else fxx1=127;
	  	}
//Joypad-1 (UP-DOWN)
    if ((up1 == 0)&&(dn1 != 0)) fyy1=255;
		  else
			 {
				  if ((up1 != 0)&&(dn1 == 0)) fyy1=0;
				  else fyy1=127;
	  	}
//Joypad-2 (LEFT-RIGHT)
    if ((lf2 == 0)&&(rg2 != 0)) fxx2=255;
		  else
		  {
				  if ((lf2 != 0)&&(rg2 == 0)) fxx2=0;
			   else fxx2=127;
	  	}
//Joypad-2 (UP-DOWN)
    if ((up2 == 0)&&(dn2 != 0)) fyy2=255;
		  else
			 {
				  if ((up2 != 0)&&(dn2 == 0)) fyy2=0;
				  else fyy2=127;
			 }
    //------------------------------------------------------------------------		
    for (k=0; k<16; k++) //Byte-6, byte-7
    { PORTC &= ~_BV(CLK1); //CLK=0
				  PORTC &= ~_BV(CLK2); //CLK=0
      for (pause=1400; pause > 0; pause--); //Time CLK (0)
      if (k==15) //Read data
      { if(bit_is_clear(PINB,DAT1)) out1[k]=1;
						  else out1[k]=0;
								if(bit_is_clear(PINC,DAT2)) out2[k]=1;
						  else out2[k]=0;
        PORTC |= _BV(CLK1); //CLK=1
								PORTC |= _BV(CLK2); //CLK=1
      }
      else
      { PORTC |= _BV(CLK1); //CLK=1
						  PORTC |= _BV(CLK2); //CLK=1
	       for (pause=100; pause > 0; pause--); //Pause
        if(bit_is_clear(PINB,DAT1)) out1[k]=1;
						  else out1[k]=0;
								if(bit_is_clear(PINC,DAT2)) out2[k]=1;
						  else out2[k]=0;
      }
      if (k==7) for (pause=3000; pause > 0; pause--); //Long pause
				  for (pause=1400; pause > 0; pause--); //Time CLK (1)
    }
    for (pause=3000; pause > 0; pause--); //Long pause
				//RIGHT analog mode (joypad-1)
    rxx1= ~((out1[7] <<7) | (out1[6] <<6) | (out1[5] <<5) | (out1[4] <<4) |
            (out1[3] <<3) | (out1[2] <<2) | (out1[1] <<1) | out1[0]);
				ryy1= ~((out1[15] <<7) | (out1[14] <<6) | (out1[13] <<5) | (out1[12] <<4) |
            (out1[11] <<3) | (out1[10] <<2) | (out1[9] <<1) | out1[8]);
 
				//RIGHT analog mode (joypad-2)
    rxx2= ~((out2[7] <<7) | (out2[6] <<6) | (out2[5] <<5) | (out2[4] <<4) |
            (out2[3] <<3) | (out2[2] <<2) | (out2[1] <<1) | out2[0]);
				ryy2= ~((out2[15] <<7) | (out2[14] <<6) | (out2[13] <<5) | (out2[12] <<4) |
            (out2[11] <<3) | (out2[10] <<2) | (out2[9] <<1) | out2[8]);
				//------------------------------------------------------------------------
    for (k=0; k<16; k++) //Byte-8, byte-9
    { PORTC &= ~_BV(CLK1); //CLK=0
				  PORTC &= ~_BV(CLK2); //CLK=0
      for (pause=1400; pause > 0; pause--); //Time CLK (0)
      if (k==15) //Read data
      { if(bit_is_clear(PINB,DAT1)) out1[k]=1;
						  else out1[k]=0;
								if(bit_is_clear(PINC,DAT2)) out2[k]=1;
						  else out2[k]=0;
        PORTC |= _BV(CLK1); //CLK=1
								PORTC |= _BV(CLK2); //CLK=1
      }
      else
      { PORTC |= _BV(CLK1); //CLK=1
						  PORTC |= _BV(CLK2); //CLK=1
	       for (pause=100; pause > 0; pause--); //Pause
        if(bit_is_clear(PINB,DAT1)) out1[k]=1;
						  else out1[k]=0;
								if(bit_is_clear(PINC,DAT2)) out2[k]=1;
						  else out2[k]=0;
      }
      if (k==7) for (pause=3000; pause > 0; pause--); //Long pause
				  for (pause=1400; pause > 0; pause--); //Time CLK (1)
				}
    //------------------------------------------------------------------------------
				if (analog1 !=0) //If analog mode enable (joypad-1)
				{
				  if ((fxx1==127)&&(fyy1==127)) //If buttons are not pressed (joypad-1)
      { //LEFT analog mode (joypad-1)
						  fxx1= ~((out1[7] <<7) | (out1[6] <<6) | (out1[5] <<5) | (out1[4] <<4) |
                (out1[3] <<3) | (out1[2] <<2) | (out1[1] <<1) | out1[0]);
						  fyy1= ~((out1[15] <<7) | (out1[14] <<6) | (out1[13] <<5) | (out1[12] <<4) |
                (out1[11] <<3) | (out1[10] <<2) | (out1[9] <<1) | out1[8]);
						}
				}
				if (analog2 !=0) //If analog mode enable (joypad-2)
				{
				  if ((fxx2==127)&&(fyy2==127)) //If buttons are not pressed (joypad-2)
      { //LEFT analog mode (joypad-2)
						  fxx2= ~((out2[7] <<7) | (out2[6] <<6) | (out2[5] <<5) | (out2[4] <<4) |
                (out2[3] <<3) | (out2[2] <<2) | (out2[1] <<1) | out2[0]);
						  fyy2= ~((out2[15] <<7) | (out2[14] <<6) | (out2[13] <<5) | (out2[12] <<4) |
                (out2[11] <<3) | (out2[10] <<2) | (out2[9] <<1) | out2[8]);
						}
				}
//----------------------------------------------------------------------------    
				if (analog1==0) rxx1=ryy1=127; //Middle of digital mode (joypad-1)
				if (analog2==0) rxx2=ryy2=127; //Middle of digital mode (joypad-2)

    PORTC |= _BV(SEL1); //SEL=1
				PORTC |= _BV(SEL2); //SEL=1
    PORTB |= _BV(CMD1); //Initial CMD=1
				PORTC |= _BV(CMD2); //Initial CMD=1

//Buttons of joypad-1
				bbb1=(l21 << 7) | (l11 << 6) | (xx1 << 5) | (oo1 << 4) |
         (aa1 << 3) | (dd1 << 2) | (st1 << 1) | sl1;
				ccc1=(jr1 << 3) | (jl1 << 2) | (r21 << 1) | r11;
//Buttons of joypad-2
				bbb2=(l22 << 7) | (l12 << 6) | (xx2 << 5) | (oo2 << 4) |
         (aa2 << 3) | (dd2 << 2) | (st2 << 1) | sl2;
				ccc2=(jr2 << 3) | (jl2 << 2) | (r22 << 1) | r12;
//Checking of present of joypads
				if (analog1==0xFF) //Joypad-1 is not found
    { rxx1=ryy1=fxx1=fyy1=127; //Middle of digital mode (joypad-1, joypad-2)
				  bbb1=ccc1=0; //Buttons are not pressed
				}
				if (analog2==0xFF) //Joypad-2 is not found
    { rxx2=ryy2=fxx2=fyy2=127; //Middle of digital mode (joypad-1, joypad-2)
				  bbb2=ccc2=0; //Buttons are not pressed
				}
//Output (joypad-1)
    psx_data[0].x = fxx1; //�
    psx_data[0].y = fyy1;	 //Y
				psx_data[0].z = rxx1; //Handle-1
				psx_data[0].p = ryy1; //Handle-2
    psx_data[0].u.buttons = bbb1; //Buttons (8)
    psx_data[0].w.but = ccc1; //Buttons (4)
//Output (joypad-2)
				psx_data[1].x = fxx2; //�
    psx_data[1].y = fyy2;	 //Y
				psx_data[1].z = rxx2; //Handle-1
				psx_data[1].p = ryy2; //Handle-2
    psx_data[1].u.buttons = bbb2; //Buttons (8)
    psx_data[1].w.but = ccc2; //Buttons (4)
		}
}
