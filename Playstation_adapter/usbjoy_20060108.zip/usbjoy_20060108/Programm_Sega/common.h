//The publication "Connection of joypads from a game consoles to the USB".
//The Russian magazine �RADIO�, 2007, number 1, pages 28-31, http://www.radio.ru
//Author � Ryumik Sergey.
//=============================================================================
//Joypads_SEGA_Mega Drive-II, "common.h"
//=============================================================================
#define F_CPU   12000000UL //Frequency ZQ1
#include <avr/io.h> //Input-output
#include <avr/interrupt.h> //Interrupts
#include <avr/pgmspace.h> //Space
//=============================================================================
#include "usbdrv.h" //Driver_USB
//=============================================================================
//Output_structure
typedef struct
{
  uchar x; //Byte-0, � (0, 1, 2)
  uchar y; //Byte-1, Y (0, 1, 2)
  union {
    uchar buttons; //Byte-2, buttons 8
    struct
    {
      uchar btn1: 1; //0, 1
      uchar btn2: 1; //0, 1
      uchar btn3: 1; //0, 1
      uchar btn4: 1; //0, 1
      uchar btn5: 1; //0, 1
      uchar btn6: 1; //0, 1
      uchar btn7: 1; //0, 1
      uchar btn8: 1; //0, 1
    } b;
  } u;
} t_SegaController;
//=============================================================================
extern t_SegaController sega_data[2];
//=============================================================================
//Functions
extern void inDecoderInit(void); //Initialization
extern void inDecoderPoll(void); //Input
extern void outSendData(void); //Output
//=============================================================================
//Configuration of ports ATmega8
#define HL1 PD4 //LED HL1
#define SYN PD3 //SYN (joypad-1, joypad-2)

#define AB1 PC1 //A/B (joypad-1)
#define SC1 PC5 //START/C (joypad-1)
#define UZ1 PC0 //UP/Z (joypad-1)
#define DY1 PC2 //RIGHT/MODE (joypad-1)
#define LX1 PC3 //LEFT/X (joypad-1)
#define RM1 PC4 //RIGHT/MODE (joypad-1)

#define AB2 PB0 //A/B (joypad-2)
#define SC2 PD5 //START/C (joypad-2)
#define UZ2 PB1 //UP/Z (joypad-2)
#define DY2 PB2 //RIGHT/MODE (joypad-2)
#define LX2 PD7 //LEFT/X (joypad-2)
#define RM2 PD6 //RIGHT/MODE (joypad-2)
